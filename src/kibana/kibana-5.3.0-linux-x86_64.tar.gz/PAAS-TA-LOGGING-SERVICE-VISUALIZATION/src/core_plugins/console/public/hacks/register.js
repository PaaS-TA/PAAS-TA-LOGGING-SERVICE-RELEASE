import devTools from 'ui/registry/dev_tools';
devTools.register(() => ({
  order: 1,
  name: 'console',
  display: 'Console',
  url: '#/dev_tools/console'
}));
