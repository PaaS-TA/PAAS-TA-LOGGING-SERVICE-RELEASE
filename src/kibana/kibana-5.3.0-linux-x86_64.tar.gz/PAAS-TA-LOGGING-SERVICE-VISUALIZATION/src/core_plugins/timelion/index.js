'use strict';

// REX
module.exports = function (kibana) {
};
