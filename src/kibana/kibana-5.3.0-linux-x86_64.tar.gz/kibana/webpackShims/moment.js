'use strict';

module.exports = require('../node_modules/moment/min/moment.min.js');
