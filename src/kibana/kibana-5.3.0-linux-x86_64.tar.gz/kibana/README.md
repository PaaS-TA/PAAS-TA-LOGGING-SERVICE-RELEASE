# PAAS-TA-LOGGING-SERVICE-VISUALIZATION
 
  PAAS-TA-LOGGING-SERVICE-VISUALIZATION is based on Kibana 5.
 
### REQUIREMENTS
- node 6.11.5
- npm 3.10.10

### REFERENCE 
- https://www.elastic.co
- https://github.com/elastic/kibana/tree/5.3

