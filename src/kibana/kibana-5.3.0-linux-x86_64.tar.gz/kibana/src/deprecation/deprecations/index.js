'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _rename2 = require('./rename');

var _rename3 = _interopRequireDefault(_rename2);

exports.rename = _rename3['default'];

var _unused2 = require('./unused');

var _unused3 = _interopRequireDefault(_unused2);

exports.unused = _unused3['default'];
