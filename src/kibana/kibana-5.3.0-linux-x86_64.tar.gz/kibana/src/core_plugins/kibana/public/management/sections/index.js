// REX
import 'plugins/kibana/management/sections/objects';
